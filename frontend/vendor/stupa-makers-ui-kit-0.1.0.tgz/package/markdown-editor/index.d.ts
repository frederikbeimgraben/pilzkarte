import * as _angular_core from '@angular/core';
import { OnDestroy } from '@angular/core';

/**
 * WYSIWYG-Markdown-Editor (Tiptap) im Stil von Nextcloud Collectives: man tippt
 * Markdown-Kürzel (`# `, `- `, `**fett**`) und sieht **sofort** das gerenderte
 * Ergebnis — kein separater Vorschau-Bereich. Ein- und Ausgabe sind Markdown.
 *
 * Imperativ angebunden: Tiptap mountet in das Host-`div`. ``docKey`` identifiziert
 * das aktuell editierte Dokument (z. B. ein TOP); ändert es sich, wird der Inhalt
 * neu geladen, ohne die Eingabe während des Tippens zu überschreiben.
 */
declare class MarkdownEditorComponent implements OnDestroy {
    /** Anfangs-/Soll-Markdown des aktuellen Dokuments. */
    readonly value: _angular_core.InputSignal<string>;
    /** Dokument-Schlüssel: ändert er sich, wird ``value`` neu in den Editor geladen. */
    readonly docKey: _angular_core.InputSignal<string>;
    readonly disabled: _angular_core.InputSignal<boolean>;
    readonly placeholder: _angular_core.InputSignal<string>;
    /** Emittiert das serialisierte Markdown bei jeder Änderung. */
    readonly valueChange: _angular_core.OutputEmitterRef<string>;
    private readonly host;
    private editor;
    private loadedKey;
    private emitting;
    constructor();
    ngOnDestroy(): void;
    /** Markdown aus dem Tiptap-Markdown-Storage holen (untypisiert in Tiptap). */
    private toMarkdown;
    static ɵfac: _angular_core.ɵɵFactoryDeclaration<MarkdownEditorComponent, never>;
    static ɵcmp: _angular_core.ɵɵComponentDeclaration<MarkdownEditorComponent, "app-markdown-editor", never, { "value": { "alias": "value"; "required": false; "isSignal": true; }; "docKey": { "alias": "docKey"; "required": false; "isSignal": true; }; "disabled": { "alias": "disabled"; "required": false; "isSignal": true; }; "placeholder": { "alias": "placeholder"; "required": false; "isSignal": true; }; }, { "valueChange": "valueChange"; }, never, never, true, never>;
}

export { MarkdownEditorComponent };
