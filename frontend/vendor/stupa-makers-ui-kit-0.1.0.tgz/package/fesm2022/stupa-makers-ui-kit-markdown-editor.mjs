import * as i0 from '@angular/core';
import { input, output, viewChild, effect, ChangeDetectionStrategy, Component } from '@angular/core';
import { Editor } from '@tiptap/core';
import StarterKit from '@tiptap/starter-kit';
import { Markdown } from 'tiptap-markdown';

/**
 * WYSIWYG-Markdown-Editor (Tiptap) im Stil von Nextcloud Collectives: man tippt
 * Markdown-Kürzel (`# `, `- `, `**fett**`) und sieht **sofort** das gerenderte
 * Ergebnis — kein separater Vorschau-Bereich. Ein- und Ausgabe sind Markdown.
 *
 * Imperativ angebunden: Tiptap mountet in das Host-`div`. ``docKey`` identifiziert
 * das aktuell editierte Dokument (z. B. ein TOP); ändert es sich, wird der Inhalt
 * neu geladen, ohne die Eingabe während des Tippens zu überschreiben.
 */
class MarkdownEditorComponent {
    constructor() {
        /** Anfangs-/Soll-Markdown des aktuellen Dokuments. */
        this.value = input('', ...(ngDevMode ? [{ debugName: "value" }] : []));
        /** Dokument-Schlüssel: ändert er sich, wird ``value`` neu in den Editor geladen. */
        this.docKey = input('', ...(ngDevMode ? [{ debugName: "docKey" }] : []));
        this.disabled = input(false, ...(ngDevMode ? [{ debugName: "disabled" }] : []));
        this.placeholder = input('', ...(ngDevMode ? [{ debugName: "placeholder" }] : []));
        /** Emittiert das serialisierte Markdown bei jeder Änderung. */
        this.valueChange = output();
        this.host = viewChild.required('host');
        this.editor = null;
        this.loadedKey = null;
        this.emitting = false;
        // Editor lazy aufbauen, sobald das Host-Element existiert, und auf
        // docKey/disabled reagieren.
        effect(() => {
            const el = this.host().nativeElement;
            const key = this.docKey();
            const disabled = this.disabled();
            if (!this.editor) {
                this.editor = new Editor({
                    element: el,
                    extensions: [StarterKit, Markdown.configure({ html: false })],
                    content: this.value(),
                    editable: !disabled,
                    editorProps: { attributes: { 'data-placeholder': this.placeholder() } },
                    onUpdate: ({ editor }) => {
                        if (this.emitting)
                            return;
                        this.valueChange.emit(this.toMarkdown(editor));
                    },
                });
                this.loadedKey = key;
                return;
            }
            this.editor.setEditable(!disabled);
            // Dokument gewechselt → Inhalt neu laden (ohne valueChange auszulösen).
            if (key !== this.loadedKey) {
                this.loadedKey = key;
                this.emitting = true;
                this.editor.commands.setContent(this.value());
                this.emitting = false;
            }
        });
    }
    ngOnDestroy() {
        this.editor?.destroy();
        this.editor = null;
    }
    /** Markdown aus dem Tiptap-Markdown-Storage holen (untypisiert in Tiptap). */
    toMarkdown(editor) {
        const storage = editor.storage;
        return storage['markdown']?.getMarkdown?.() ?? '';
    }
    static { this.ɵfac = i0.ɵɵngDeclareFactory({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: MarkdownEditorComponent, deps: [], target: i0.ɵɵFactoryTarget.Component }); }
    static { this.ɵcmp = i0.ɵɵngDeclareComponent({ minVersion: "17.2.0", version: "20.3.25", type: MarkdownEditorComponent, isStandalone: true, selector: "app-markdown-editor", inputs: { value: { classPropertyName: "value", publicName: "value", isSignal: true, isRequired: false, transformFunction: null }, docKey: { classPropertyName: "docKey", publicName: "docKey", isSignal: true, isRequired: false, transformFunction: null }, disabled: { classPropertyName: "disabled", publicName: "disabled", isSignal: true, isRequired: false, transformFunction: null }, placeholder: { classPropertyName: "placeholder", publicName: "placeholder", isSignal: true, isRequired: false, transformFunction: null } }, outputs: { valueChange: "valueChange" }, viewQueries: [{ propertyName: "host", first: true, predicate: ["host"], descendants: true, isSignal: true }], ngImport: i0, template: "<div #host class=\"mde__host\" [class.mde__host--disabled]=\"disabled()\"></div>\n", styles: [":host{display:block}.mde__host{min-height:16rem;padding:var(--space-3) var(--space-4);background:var(--color-surface);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);overflow-wrap:anywhere}.mde__host--disabled{opacity:.7}.mde__host :first-child{margin-top:0}.mde__host .ProseMirror{outline:none;min-height:14rem;line-height:1.55}.mde__host .ProseMirror h1{font-size:var(--fs-xl)}.mde__host .ProseMirror h2{font-size:var(--fs-lg)}.mde__host .ProseMirror h3{font-size:var(--fs-md);font-weight:var(--fw-semibold)}.mde__host .ProseMirror ul,.mde__host .ProseMirror ol{padding-left:var(--space-5);margin:var(--space-2) 0}.mde__host .ProseMirror blockquote{margin:var(--space-2) 0;padding-left:var(--space-3);border-left:3px solid var(--color-border-strong);color:var(--color-text-muted)}.mde__host .ProseMirror code{background:var(--color-bg);padding:0 var(--space-1);border-radius:var(--radius-sm);font-size:.9em}.mde__host .ProseMirror pre{background:var(--color-bg);padding:var(--space-3);border-radius:var(--radius-md);overflow-x:auto}.mde__host .ProseMirror hr{border:0;border-top:var(--border-width) solid var(--color-border);margin:var(--space-3) 0}.mde__host .ProseMirror p.is-editor-empty:first-child:before{content:attr(data-placeholder);color:var(--color-text-muted);float:left;height:0;pointer-events:none}\n"], changeDetection: i0.ChangeDetectionStrategy.OnPush }); }
}
i0.ɵɵngDeclareClassMetadata({ minVersion: "12.0.0", version: "20.3.25", ngImport: i0, type: MarkdownEditorComponent, decorators: [{
            type: Component,
            args: [{ selector: 'app-markdown-editor', standalone: true, changeDetection: ChangeDetectionStrategy.OnPush, template: "<div #host class=\"mde__host\" [class.mde__host--disabled]=\"disabled()\"></div>\n", styles: [":host{display:block}.mde__host{min-height:16rem;padding:var(--space-3) var(--space-4);background:var(--color-surface);border:var(--border-width) solid var(--color-border-strong);border-radius:var(--radius-md);overflow-wrap:anywhere}.mde__host--disabled{opacity:.7}.mde__host :first-child{margin-top:0}.mde__host .ProseMirror{outline:none;min-height:14rem;line-height:1.55}.mde__host .ProseMirror h1{font-size:var(--fs-xl)}.mde__host .ProseMirror h2{font-size:var(--fs-lg)}.mde__host .ProseMirror h3{font-size:var(--fs-md);font-weight:var(--fw-semibold)}.mde__host .ProseMirror ul,.mde__host .ProseMirror ol{padding-left:var(--space-5);margin:var(--space-2) 0}.mde__host .ProseMirror blockquote{margin:var(--space-2) 0;padding-left:var(--space-3);border-left:3px solid var(--color-border-strong);color:var(--color-text-muted)}.mde__host .ProseMirror code{background:var(--color-bg);padding:0 var(--space-1);border-radius:var(--radius-sm);font-size:.9em}.mde__host .ProseMirror pre{background:var(--color-bg);padding:var(--space-3);border-radius:var(--radius-md);overflow-x:auto}.mde__host .ProseMirror hr{border:0;border-top:var(--border-width) solid var(--color-border);margin:var(--space-3) 0}.mde__host .ProseMirror p.is-editor-empty:first-child:before{content:attr(data-placeholder);color:var(--color-text-muted);float:left;height:0;pointer-events:none}\n"] }]
        }], ctorParameters: () => [], propDecorators: { value: [{ type: i0.Input, args: [{ isSignal: true, alias: "value", required: false }] }], docKey: [{ type: i0.Input, args: [{ isSignal: true, alias: "docKey", required: false }] }], disabled: [{ type: i0.Input, args: [{ isSignal: true, alias: "disabled", required: false }] }], placeholder: [{ type: i0.Input, args: [{ isSignal: true, alias: "placeholder", required: false }] }], valueChange: [{ type: i0.Output, args: ["valueChange"] }], host: [{ type: i0.ViewChild, args: ['host', { isSignal: true }] }] } });

/*
 * Secondary entry point '@stupa-makers/ui-kit/markdown-editor'.
 * Isolated so the Tiptap dependency stays out of the primary entry's bundle and lands in
 * the consumer's lazy chunk only where the editor is actually used.
 */

/**
 * Generated bundle index. Do not edit.
 */

export { MarkdownEditorComponent };
//# sourceMappingURL=stupa-makers-ui-kit-markdown-editor.mjs.map
